// Paste the full Opecbank React app code here
import React from 'react';

const App = () => {
  return <div>Opecbank App - Replace with full code</div>;
};

export default App;
